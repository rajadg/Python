'''
Created on 02-Aug-2015

@author: dgraja
'''

def add(a, b):
    return a+b

def main():
    print "hello world !!"
    print add(11, 34)

if __name__ == '__main__':
    main()
    pass